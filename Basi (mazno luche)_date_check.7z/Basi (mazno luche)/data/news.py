import datetime
import sqlalchemy
from sqlalchemy import orm, create_engine
from sqlalchemy.orm import Session
from .db_session import SqlAlchemyBase

sqlite_database = "sqlite:///blogs.db"
engine = create_engine(sqlite_database, echo=True)

class Asortiment(SqlAlchemyBase):
    __tablename__ = 'asortiment'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    status = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    arend = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    photo_href = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    id_type = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('idtype.id'))
    is_private = sqlalchemy.Column(sqlalchemy.Boolean, default=True)

    user_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    users = orm.relationship('Users')
    idtype = orm.relationship("Idtype", secondary="association", backref="asortiment")
    request = orm.relationship("Request", back_populates='asortiment')


class Request(SqlAlchemyBase):
    __tablename__ = 'request'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    description = sqlalchemy.Column(sqlalchemy.String)
    date_start = sqlalchemy.Column(sqlalchemy.DateTime)
    date_end = sqlalchemy.Column(sqlalchemy.DateTime)

    id_user = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    users = orm.relationship('Users')
    id_item = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("asortiment.id"))
    asortiment = orm.relationship("Asortiment")

    # def date_check(self, data_start, data_end):
    #     with Session(autoflush=False, bind=engine) as db:
    #         # получение всех объектов
    #         dates = db.query(Request).all()
    #         for p in dates:
    #             if self.date_start > p.date_start and self.date_start < p.date_end and self.date_end < p.date_end and self.date_end > p.date_start:
    #                 return False
    #             if self.date_start < p.date_start and self.date_start < p.date_end and self.date_end < p.date_end and self.date_end > p.date_start:
    #                 return False
    #             if self.date_start > p.date_start and self.date_start < p.date_end and self.date_end > p.date_end and self.date_end > p.date_start:
    #                 return False
    #             else:
    #                 return True